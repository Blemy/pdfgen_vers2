from setuptools import setup,find_packages

setup(
    name='pdgenere',
    description='PDF dynamique',
    packages=['pdgenere'],
    version='9.1',
    author='Blemy',
    author_email='mathieublemy@01gmail.com'
)
